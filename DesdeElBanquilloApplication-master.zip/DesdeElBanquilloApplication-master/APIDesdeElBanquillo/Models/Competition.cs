﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Metrics;
using System.Text.RegularExpressions;

namespace APIDesdeElBanquillo.Models
{
    [Table("Competitions")]
    public class Competition
    {
        [Key]
        public int IdCompetition { get; set; }

        [Required]
        [StringLength(100)]
        [DisplayName("Nombre Competicion")]
        public string Name { get; set; } = string.Empty;

        [StringLength(20)]
        [DisplayName("Temporada Competicion")]
        public string? Season { get; set; }

        [ForeignKey("Country")]
        public int CountryId { get; set; }

        [ForeignKey("Federation")]
        public int FederationId { get; set; }

        public virtual Country? Country { get; set; }
        public virtual Federation? Federation { get; set; }

        public virtual ICollection<Team> Teams { get; set; } = new List<Team>();
        public virtual ICollection<Match> Matches { get; set; } = new List<Match>();
    }
}