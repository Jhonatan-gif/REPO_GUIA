﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APIDesdeElBanquillo.Models
{
    [Table("Federations")]
    public class Federation
    {
        [Key]
        public int IdFederation { get; set; }

        [Required]
        [StringLength(100)]
        [DisplayName("Nombre Federacion")]
        public string Name { get; set; } = string.Empty;

        [StringLength(20)]
        public string? Acronym { get; set; }

        [DisplayName("Fecha de Creacion Federacion")]
        public DateTime EstablishedDate { get; set; }

        [Required]
        [ForeignKey("Country")]
        [DisplayName("País")]
        public int CountryId { get; set; }

        public virtual Country? Country { get; set; }

        public virtual ICollection<Competition> Competitions { get; set; } = new List<Competition>();
    }
}