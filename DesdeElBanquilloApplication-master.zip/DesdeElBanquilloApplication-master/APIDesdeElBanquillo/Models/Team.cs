﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APIDesdeElBanquillo.Models
{
    [Table("Teams")]
    public class Team
    {
        [Key]
        public int IdTeam { get; set; }

        [Required]
        [StringLength(100)]
        [DisplayName("Nombre Equipo")]
        public string Name { get; set; } = string.Empty;

        [StringLength(50)]
        [DisplayName("Ciudad Equipo")]
        public string? City { get; set; }

        [DisplayName("Fecha Fundacion Equipo")]
        public DateTime FoundedDate { get; set; }

        [ForeignKey("Competition")]
        public int CompetitionId { get; set; }

        [ForeignKey("Country")]
        public int CountryId { get; set; }

        [ForeignKey("League")]
        public int LeagueId { get; set; }

        public virtual Competition? Competition { get; set; }
        public virtual Country? Country { get; set; }
        public virtual Stadium? Stadium { get; set; }
        public virtual League? League { get; set; }

        public virtual ICollection<Player> Players { get; set; } = new List<Player>();

        [InverseProperty("HomeTeam")]
        public virtual ICollection<Match> HomeMatches { get; set; } = new List<Match>();

        [InverseProperty("AwayTeam")]
        public virtual ICollection<Match> AwayMatches { get; set; } = new List<Match>();
    }
}