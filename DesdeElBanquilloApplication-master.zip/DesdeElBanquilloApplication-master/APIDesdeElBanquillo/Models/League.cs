﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APIDesdeElBanquillo.Models
{
    [Table("Leagues")]
    public class League
    {
        [Key]
        public int IdLeague { get; set; }

        [Required]
        [StringLength(100)]
        [DisplayName("Nombre Liga")]
        public string Name { get; set; } = string.Empty;

        [DisplayName("Fecha Creacion Liga")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        [DisplayName("Liga Activa")]
        public bool IsActive { get; set; } = true;

        [ForeignKey("Country")]
        public int CountryId { get; set; }

        public virtual Country? Country { get; set; }

        public virtual ICollection<Team> Teams { get; set; } = new List<Team>();
        public virtual ICollection<Season> Seasons { get; set; } = new List<Season>();
    }
}