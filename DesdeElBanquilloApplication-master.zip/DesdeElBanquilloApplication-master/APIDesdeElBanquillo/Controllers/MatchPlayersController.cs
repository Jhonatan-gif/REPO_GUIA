﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APIDesdeElBanquillo.Models;

namespace APIDesdeElBanquillo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MatchPlayersController : ControllerBase
    {
        private readonly APIDesdeElBanquilloDb _context;

        public MatchPlayersController(APIDesdeElBanquilloDb context)
        {
            _context = context;
        }

        // GET: api/MatchPlayers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MatchPlayer>>> GetMatchPlayer()
        {
            return await _context.MatchPlayer.ToListAsync();
        }

        // GET: api/MatchPlayers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<MatchPlayer>> GetMatchPlayer(int id)
        {
            var matchPlayer = await _context.MatchPlayer.FindAsync(id);

            if (matchPlayer == null)
            {
                return NotFound();
            }

            return matchPlayer;
        }

        // PUT: api/MatchPlayers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMatchPlayer(int id, MatchPlayer matchPlayer)
        {
            if (id != matchPlayer.IdMatchPlayers)
            {
                return BadRequest();
            }

            _context.Entry(matchPlayer).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MatchPlayerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MatchPlayers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<MatchPlayer>> PostMatchPlayer(MatchPlayer matchPlayer)
        {
            _context.MatchPlayer.Add(matchPlayer);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMatchPlayer", new { id = matchPlayer.IdMatchPlayers }, matchPlayer);
        }

        // DELETE: api/MatchPlayers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMatchPlayer(int id)
        {
            var matchPlayer = await _context.MatchPlayer.FindAsync(id);
            if (matchPlayer == null)
            {
                return NotFound();
            }

            _context.MatchPlayer.Remove(matchPlayer);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool MatchPlayerExists(int id)
        {
            return _context.MatchPlayer.Any(e => e.IdMatchPlayers == id);
        }
    }
}
