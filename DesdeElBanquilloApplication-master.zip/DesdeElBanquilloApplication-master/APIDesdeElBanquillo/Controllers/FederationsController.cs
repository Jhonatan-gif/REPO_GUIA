﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APIDesdeElBanquillo.Models;

namespace APIDesdeElBanquillo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FederationsController : ControllerBase
    {
        private readonly APIDesdeElBanquilloDb _context;

        public FederationsController(APIDesdeElBanquilloDb context)
        {
            _context = context;
        }

        // GET: api/Federations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Federation>>> GetFederation()
        {
            return await _context.Federation.ToListAsync();
        }

        // GET: api/Federations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Federation>> GetFederation(int id)
        {
            var federation = await _context.Federation.FindAsync(id);

            if (federation == null)
            {
                return NotFound();
            }

            return federation;
        }

        // PUT: api/Federations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutFederation(int id, Federation federation)
        {
            if (id != federation.IdFederation)
            {
                return BadRequest();
            }

            _context.Entry(federation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FederationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Federations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Federation>> PostFederation(Federation federation)
        {
            _context.Federation.Add(federation);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetFederation", new { id = federation.IdFederation }, federation);
        }

        // DELETE: api/Federations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFederation(int id)
        {
            var federation = await _context.Federation.FindAsync(id);
            if (federation == null)
            {
                return NotFound();
            }

            _context.Federation.Remove(federation);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool FederationExists(int id)
        {
            return _context.Federation.Any(e => e.IdFederation == id);
        }
    }
}
